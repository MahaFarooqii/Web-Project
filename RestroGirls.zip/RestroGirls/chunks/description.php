<section class="fdes">
		<div class="section white center">
			<h2 class="header" style="padding:20px; padding-bottom: 30px;">Resturant Powered By Girls</h2>
		      <div class="row container center">
		        <div class="col center l8 s12">
		        	<p>We make everything by hand with the best possible ingredients. We have worked for people in general and have advanced into a combination between exquisite chic and contemporary fine charge.
                            Enjoy our dazzling dishes and make the most of your eating background with us!We pride ourselves on making real food from the best ingredients.We welcome you to sit back, unwind and appreciate the lovely sights and hints of the ocean while our best gourmet expert sets you up a scrumptious dinner utilizing the best and freshest ingredients.</p>
		        </div>
		        <div class="col center l4 s12">
		        	<img height="300" width="auto" style="object-fit: contain;" src="images/17964.jpg" alt="">
		        </div>
		        
		      </div>
	</section>