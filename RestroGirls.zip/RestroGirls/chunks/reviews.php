<section class="freviews">

		<div class="section white center">
			<h3 class="header">What Our Customers Say</h3>
			<div class="carousel myreviews" style="margin-bottom: 35px;">
			    <a class="carousel-item" href="#one!">
			    	<div class="row">
					    <div class="col s12">
					      <div class="card-panel teal" style="background: #8b8989 !important;">
					        <span class="white-text">"The food of this resturant is just like heaven for me! Its so delicious and tasty that I can't help going there every weekend!"<br>-<br> <strong>Ramkesh Singh</strong>
					        </span>
					      </div>
					    </div>
					  </div>
			    </a>
			    <a class="carousel-item" href="#two!">
			    	<div class="row">
					    <div class="col s12">
					      <div class="card-panel teal" style="background: #8b8989 !important;">
					        <span class="white-text">"The food of this resturant is just like heaven for me! Its so delicious and tasty that I can't help going there every weekend!"<br>-<br> <strong>Rohan Roy</strong>
					        </span>
					      </div>
					    </div>
					  </div>
			    </a>
			    <a class="carousel-item" href="#three!">
			    	<div class="row">
					    <div class="col s12">
					      <div class="card-panel teal" style="background: #8b8989 !important;">
					        <span class="white-text">"The food of this resturant is just like heaven for me! Its so delicious and tasty that I can't help going there every weekend!"<br>-<br> <strong>Atul Chand</strong>
					        </span>
					      </div>
					    </div>
					  </div>
			    </a>
			    <a class="carousel-item" href="#four!">
			    	<div class="row">
					    <div class="col s12">
					      <div class="card-panel teal" style="background: #8b8989 !important;">
					        <span class="white-text">"The food of this resturant is just like heaven for me! Its so delicious and tasty that I can't help going there every weekend!"<br>-<br> <strong>Farhan Ahmed</strong>
					        </span>
					      </div>
					    </div>
					  </div>
			    </a>
			    <a class="carousel-item" href="#five!">
			    	<div class="row">
					    <div class="col s12">
					      <div class="card-panel teal" style="background: #8b8989 !important;">
					        <span class="white-text">"The food of this resturant is just like heaven for me! Its so delicious and tasty that I can't help going there every weekend!"<br>-<br> <strong>Riya Dutta</strong>
					        </span>
					      </div>
					    </div>
					  </div>
			    </a>
			    <a class="carousel-item" href="#six!">
			    	<div class="row">
					    <div class="col s12">
					      <div class="card-panel teal" style="background: #8b8989 !important;">
					        <span class="white-text">"The food of this resturant is just like heaven for me! Its so delicious and tasty that I can't help going there every weekend!"<br>-<br> <strong>Jasmine Sinha</strong>
					        </span>
					      </div>
					    </div>
					  </div>
			    </a>
			    <a class="carousel-item" href="#seven!">
			    	<div class="row">
					    <div class="col s12">
					      <div class="card-panel teal" style="background: #8b8989 !important;">
					        <span class="white-text">"The food of this resturant is just like heaven for me! Its so delicious and tasty that I can't help going there every weekend!"<br>-<br> <strong>Sangjukta Roy</strong>
					        </span>
					      </div>
					    </div>
					  </div>
			    </a>
			  </div>
		</div>
	</section>